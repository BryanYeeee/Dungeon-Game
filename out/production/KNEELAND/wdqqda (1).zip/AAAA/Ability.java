import java.util.Random;

public class Ability extends Item{
	String dir = "AbilityIcon.png";
    public static Random rand = new Random();
    public Ability() {

    }
    int unlocked = 0;
    public void pickUp(Player person) {
        System.out.println("NEW THING YOU CAN DOOOOOOOOOOO");
        unlocked++;
        switch(unlocked){
          case 1:
            person.inv.atks.add("FTStrike");
          break;
          case 2:
            person.inv.atks.add("Heal");
          break;
          case 3:
            person.inv.atks.add("Stun");
          break;

        }
        return;
    }
    public static int FTStrike(Player person)  {
      int hits = rand.nextInt(3) + 2;
      System.out.println("You hit "+hits+" times");
      return person.strength*hits;
    }
    
    public static int Stun(Player person)  {
      
      System.out.println("You dealt half the damage");
      return person.strength/2;
    }

}