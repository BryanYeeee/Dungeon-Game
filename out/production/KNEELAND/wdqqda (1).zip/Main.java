import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.*;

public class Main {
    
    public static Player person;
    public static int currentLvl;
    public static ArrayList<Level> arlofLevels;
		public static GUI gui;

    public static void main(String args[]) {
      
        startGame();
        gui = new GUI();
       

    }
    public static void startGame(){
      person = new Player(4/*default 4*/,15000/*default 150*/,0);
      currentLvl = 4;//+1
      arlofLevels = (new LevelList()).arlofLevels;


      Scanner sc = new Scanner(System.in);
      System.out.println("+------ WELCOME TO YOUR ROOM ------+");
      System.out.println("|        -- Pick a Stick --        |");
      System.out.println("| -+ (1)Sword (2)Wand (3)Hammer +- |");
      System.out.println("|        -- Pick a Stick --        |");
      System.out.println("+---- -+--------------------+- ----+");
      
      person.setLocation(arlofLevels.get(currentLvl).startx, arlofLevels.get(currentLvl).starty);
      
    }
    public void pickWeapon(String weapon){
      boolean yesWeapon = false;
              while (!yesWeapon){
                  switch(weapon) {
                      case "Sword":
                          person.inv.upgradeWeapon("Sword", 2);
                          yesWeapon = true;
                          break;
                      case "Wand":
                          person.inv.upgradeWeapon("Wand", 2);
                          yesWeapon = true;
                          break;
                      case "Hammer":
                          person.inv.upgradeWeapon("Hammer", 2);
                          yesWeapon = true;
                          break;

                  
                }
              }
    }

}