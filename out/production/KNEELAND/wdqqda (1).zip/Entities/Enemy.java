public class Enemy {
  
    String name;
    public int health;
    public int strength;
    String weak;
    String resist;
    int x;
    int y;
    int richness;
    int keyDrop = 0;
    

    public Enemy(int strength, int health, int x, int y, int richness, String weak, String resist, String name) {
        this.health = health;
        this.strength = strength;
        this.x = x;
        this.y = y;
        this.richness = richness;
        this.weak = weak;
        this.resist = resist;
        this.name = name;
    }

    public void addKey(int id) {
        this.keyDrop = id;
        return;
    }

}