import java.util.Random;
import java.util.Scanner;
import java.awt.*;
import java.awt.event.*;

public class Player {
    int strength;
    int health;
    int worth;
    int x;
    int y;
    public boolean isAlive = true;
    public boolean atLadder = false;
    public static Inventory inv = new Inventory();

    public Player(int strength, int health, int worth){
        this.strength = strength;
        this.health = health;
        this.worth = worth;
    }

    public void setLocation(int x, int y) {
        this.x = x;
        this.y = y;
        return;
    }

    public boolean move(String move, Level level, boolean doMove) {
        try {
            String Direction = move.substring(0, 1);
            int movex = 0, movey = 0;

            switch (Direction) {
                case "w":
                    movex = -1;
                    break;
                case "a":
                    movey = -1;
                    break;
                case "s":
                    movex = 1;
                    break;
                case "d":
                    movey = 1;
                    break;
            }
            if (level.map[this.x + movex][this.y + movey].object instanceof Wall) {
                return false;
            }
            if(doMove) {

                Object thing = level.map[this.x + movex][this.y + movey].object;

                if(thing instanceof Item) {

                    ((Item)thing).pickUp(this);
                    level.map[this.x + movex][this.y + movey] = new Tile(" - ");

                } else if(thing instanceof Ladder) {

                    this.atLadder = true;
                    return true;

                } else if (thing instanceof Enemy) {

                    Enemy victim = ((Enemy)thing);
                    Fight battle = new Fight(victim);
                    Main.gui.fightScene = new fightGUI(victim, battle);
                    (Main.gui.fightScene).startFight((Main.gui).fightScene, victim, battle);
                    
                    level.map[this.x + movex][this.y + movey] = new Tile(" - ");
										return false;
                   

                } else if (thing instanceof Shop) {
                    Shop curShop = ((Shop)thing);
                    Main.gui.shopScene = new shopGUI(curShop);
                    (Main.gui.shopScene).startShop((Main.gui).shopScene);
                
                    ((Shop)thing).outputShop(this);
                    return false;
                } else if (thing instanceof Door) {
                    if(this.inv.items.contains("<"+(((Door)level.map[this.x + movex][this.y + movey].object).id)+">")) {
                        level.map[this.x + movex][this.y + movey] = new Tile(" - ");
                    } else {
                        System.out.println("You need a key");
                        return false;
                    }
                } else if (thing instanceof Teleporter) {
                    level.map[((Teleporter)thing).x][((Teleporter)thing).y] = level.map[this.x][this.y];
                    level.map[this.x][this.y] = new Tile(" - ");
                this.setLocation(((Teleporter)thing).x, ((Teleporter)thing).y);
										// Main.gui.updateBar();
                    return true;
               } else if (thing instanceof Neelan) {
                   Neelan.speak();
                   return false;
                } else if (thing instanceof Cipher) {
                    Cipher curCipher = ((Cipher)thing);
                    Main.gui.ciphScene = new cipherGUI(curCipher);
                    (Main.gui.ciphScene).startCipher((Main.gui).ciphScene);
                    
                    // if(!(((Cipher)thing).hack())) {
                    //     this.health = this.health - ((Cipher)thing).dif*10;
                    //     return false;
                    // }
                    level.map[this.x + movex][this.y + movey] = new Tile(" - ");
                    this.worth = this.worth + ((((Cipher)thing).dif)*5);
                }
                Tile tempTile = level.map[this.x + movex][this.y + movey]; //swapping tiles to move
                level.map[this.x + movex][this.y + movey] = level.map[this.x][this.y];
                level.map[this.x][this.y] = tempTile;
                this.setLocation(this.x + movex, this.y + movey);
            }
            return true;
        } catch (ArrayIndexOutOfBoundsException | NumberFormatException | StringIndexOutOfBoundsException e) {
            System.out.println("Error in Move: " + e);
            return false;
        }
    }


}
