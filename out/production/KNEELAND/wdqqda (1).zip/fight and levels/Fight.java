import java.util.Random;
import java.util.Scanner;

public class Fight{
	static int eHealth;
	static int eStrength;
	static int eWorth;
	static String eWeak;
	static String eResist;
	static int eKey;
  static int stunned;
  static boolean enemyturn;
  static Random rand = new Random();
	static String Winner;

	public Fight(Enemy victim) {
		this.eHealth = victim.health;
		this.eStrength = victim.strength;
		this.eWorth = victim.richness;
		this.eWeak = victim.weak;
		this.eResist = victim.resist;
		this.eKey = victim.keyDrop;
    this.stunned =0;
    this.enemyturn = true;
    Main.person.inv.curatks = Main.person.inv.atks;
	}
	public static void attack(Weapon weapon) {
		System.out.println("== phealth:" + Main.person.health + " pStrength:" + Main.person.strength + " eHealth:" + eHealth + " eStrength:" + eStrength + " ==");
    double weaponBonus = 1;
      if(eWeak.equals(weapon.name)){
      	weaponBonus = 1.5;
      } else if(eResist.equals(weapon.name)){
        weaponBonus = 0.75;
      }
      if(rand.nextInt(4) > 3) {
         weaponBonus = weaponBonus + 0.5;
      } 
      System.out.println("Damage Dealth: " + (int)((weapon.damage*Main.person.strength)*weaponBonus));
      eHealth = eHealth - 
      (int)((weapon.damage*Main.person.strength)*weaponBonus);
      
		if(!fightOver()) {
			enemyAttack();
			if(!fightOver()) {
				return;
			}
		}
		return;
	}
	public static void ability(String choose) {
    
      switch(choose){
          case "FTStrike":
          if(Main.person.inv.curatks.contains("FTStrike")){
          Main.person.inv.curatks.remove("FTStrike");  
          eHealth = eHealth - Ability.FTStrike(Main.person);
          }
          break;
          case "Heal":
          if(Main.person.inv.curatks.contains("Heal")){
          Main.person.inv.curatks.remove("Heal");  
          Main.person.health = eHealth;
          }
          break;
          case "Stun":
          if(Main.person.inv.curatks.contains("Stun")){
          Main.person.inv.curatks.remove("Stun");  
          eHealth = eHealth - Ability.Stun(Main.person);
            if(rand.nextInt(3) == 1){
              System.out.println("ENEMY is now crippled! :D");
                enemyturn=false;
                stunned=2;
            }
          }
          break;
        }
        if(!fightOver()) {//SOMETHING TO DO WITH STUN
          enemyAttack();
          if(!fightOver()) {
            return;
          }
        }
    
	}
	public static void enemyAttack() {
    if(stunned<=0){
      Main.person.health = Main.person.health-(rand.nextInt(10) + eStrength);
    }else{
      stunned--;
    }
	}
	public static boolean fightOver() {
		if(Main.person.health <= 0) {
			Winner = "Enemy";
      
			fightGUI.endFight();
			return true;
		} else if(eHealth <= 0) {
			Winner = "Player";
      Main.person.worth = Main.person.worth + eWorth;
      if(eKey > 0) {
          Main.person.inv.add("<"+eKey+">");
      }

			fightGUI.endFight();
			return true;
		} else {
			return false;
		}
	}

//   public static void battle(int eHealth, int eStrength, int eWorth, String eWeak, String eResist, int eKey) {// e=enemy
//           Scanner sc = new Scanner(System.in);;
//           boolean enemyturn = true;
//           int stunned = 0;
//           Main.person.inv.curatks = Main.person.inv.atks;
//           while(Main.person.health>0&&eHealth>0){    
//               System.out.println("== phealth:" + Main.person.health + " pStrength:" + Main.person.strength + " eHealth:" + eHealth + " eStrength:" + eStrength + " ==");
//               //Your Turn
//               System.out.println("Your Turn:1[sword] 2[spell] 3[hammer] 4[Ability]");
//               String move = "1";
//               double weaponBonus = 1;
//               if(eWeak.equals(move)){
//                 weaponBonus = 1.5;
//               } else if(eResist.equals(move)){
//                 weaponBonus = 0.75;
//               }
//               if(rand.nextInt(4) > 3) {
//                 weaponBonus = weaponBonus + 0.5;
//               } 
//               switch(move) {
//                 case "sword": 
//             System.out.println((int)((Main.person.inv.sword.damage*Main.person.strength)*weaponBonus));
//                   eHealth = eHealth - 
//                   (int)((Main.person.inv.sword.damage*Main.person.strength)*weaponBonus);
//                   break;
//                 case "spell":
//             System.out.println((int)((Main.person.inv.spell.damage*Main.person.strength)*weaponBonus));
//                   eHealth = eHealth - 
//                   (int)((Main.person.inv.spell.damage*Main.person.strength)*weaponBonus);
//                   break;
//                 case "hammer":
//             System.out.println((int)((Main.person.inv.hammer.damage*Main.person.strength)*weaponBonus));
//                   eHealth = eHealth - 
//                   (int)((Main.person.inv.hammer.damage*Main.person.strength)*weaponBonus);
//                   break;
//                 case "ability":
              
//                 String ability = sc.nextLine();
//                 switch(ability){
//                   case "1":
//                   if(Main.person.inv.curatks.contains("FTStrike")){
//                   Main.person.inv.curatks.remove("FTStrike");  
//                   eHealth = eHealth - Ability.FTStrike(Main.person);
//                   }
//                   break;
//                   case "2":
//                   if(Main.person.inv.curatks.contains("Heal")){
//                   Main.person.inv.curatks.remove("Heal");  
//                   Main.person.health = eHealth;
//                   }
//                   break;
//                   case "3":
//                   if(Main.person.inv.curatks.contains("Heal")){
//                   Main.person.inv.curatks.remove("Heal");  
//                   eHealth = eHealth - Ability.Stun(Main.person);
//                     if(rand.nextInt(3) == 1){
//                       System.out.println("ENEMY is now crippled! :D");
//                         enemyturn=false;
//                         stunned=2;
//                     }
//                   }
//                   break;
//                 }
//                 break;
//               }
//               if(eHealth <= 0) {
//                   Main.person.worth = Main.person.worth + eWorth;
//                   if(eKey > 0) {
//                       Main.person.inv.add("<"+eKey+">");
//                   }
//                   return;
//               }
//               //EMemy Eturn
//               stunned--;
//               if(stunned<=0){
//               enemyturn = true;

//               }
//               if(enemyturn){
//               Main.person.health=Main.person.health-(rand.nextInt(10) + eStrength);
//             }
//           }
//               if(Main.person.health <= 0) {
//                   Main.person.health = 0;
//                   Main.person.isAlive = false;
// 									GUI.fightGUI.endFight();
//                   return;
//               }
//       }
 }