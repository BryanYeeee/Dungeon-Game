import java.util.ArrayList;

  public class Inventory {
    ArrayList<String> items;
    ArrayList<String> atks;
    ArrayList<String> curatks;
    Sword sword;
    Spell spell;
    Hammer hammer;

    public Inventory() {

        this.items = new ArrayList<String>();
        this.atks = new ArrayList<String>();
        this.curatks = new ArrayList<String>();
        this.sword = new Sword(1.5,"sword");
        this.spell = new Spell(1.5,"spell");
        this.hammer = new Hammer(1.5,"hammer");
        this.items.add("Sword(1.5)");
        this.items.add("Wand(1.5)");
        this.items.add("Hammer(1.5)");
    }

    public void upgradeWeapon(String item, int buff) {
      switch(item) {
        case "Sword":
          this.items.remove(item+"("+this.sword.damage+")");
          this.sword.damage = buff;
          break;
        case "Wand":
          this.items.remove(item+"("+this.spell.damage+")");
          this.spell.damage = buff;
          break;
        case "Hammer":
        this.items.remove(item+"("+this.hammer.damage+")");
          this.hammer.damage = buff;
          break;
      }
      this.items.add(item + "("+buff+")");
      return;
    }

    public void clearKeys() {
        ArrayList<String> nokeys = new ArrayList<String>();
        for(int i=0;i<this.items.size();i++){
          if(this.items.get(i).charAt(0)!='<'){
            nokeys.add(this.items.get(i));

            
          }
        }
        this.items = nokeys;
        return;
    }

    public void add(String item){
        this.items.add(item); 
    }
}
