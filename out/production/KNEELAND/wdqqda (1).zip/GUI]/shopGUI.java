import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
    
    public class shopGUI extends JPanel{
      public static JPanel shopButtons;
      public static int curItem;
      public Shop curShop;

        shopGUI(Shop curShop) {
					super(new BorderLayout());
					  this.curShop = curShop;
            JLabel name = new JLabel("Sshop");
            this.add(name, BorderLayout.NORTH);
            JButton exit = new JButton("IMPOOR");


            this.setBackground(Color.RED);
						shopButtons = new JPanel();
						shopButtons.setLayout(new GridLayout(1,3));
						this.add(shopButtons, BorderLayout.CENTER);

            ArrayList<buyButton> buttons = new ArrayList<buyButton>();

            for(curItem=0;curItem<curShop.items.size();curItem++){

              buttons.add(new buyButton((String)((String[])curShop.items.get(curItem))[0]+" "+((String[])curShop.items.get(curItem))[1]+" "+((String[])curShop.items.get(curItem))[2], curItem));

              shopButtons.add(buttons.get(curItem));

            }
            exit.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
											System.out.println(Main.gui.shopScene.curItem
											);
                      Main.gui.shopScene.endShop();
                    }
            });
            shopButtons.add(exit);
            this.setPreferredSize(new Dimension(500,500));
            validate();
        }


        public static void endShop() {
            GUI.updateBar();
            GUI.toggleMove(true);
            GUI.mainPanel.remove(GUI.shopScene);
            GUI.mainPanel.add(GUI.scrollBar, BorderLayout.CENTER);
            GUI.map.updateMap();
            GUI.frame.validate();
            GUI.frame.repaint();
            System.out.println("You've BUY STUFF");
        }
        public static void startShop(shopGUI shopScene){
                    
                    GUI.mainPanel.removeAll();
                    GUI.toggleMove(false);
                    GUI.mainPanel.add(shopScene);
                    GUI.shopScene.validate();
                    GUI.shopScene.repaint();
                    GUI.mainPanel.validate();
                    GUI.mainPanel.repaint();
                    GUI.frame.validate();
                    GUI.frame.repaint();
          
        }
                   
    }
  
