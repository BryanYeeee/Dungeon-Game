import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

  public class buyButton extends JButton{
      public static int itemNumber;

      public buyButton(String text,int itemNumber){
				super(text);
        this.itemNumber = itemNumber;

				this.addActionListener(new ActionListener(){		
					@Override
                    public void actionPerformed(ActionEvent e) {
                      Main.gui.shopScene.curShop.buy(Main.person, itemNumber);
                    }
				});
      }
    }

