import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

    public class mapGUI extends JPanel {
        tileGUI[][] Panels;
        public mapGUI() {
            //8 8 = length width of mapgraphics
						this.updateMap();
        }
        public void updateMap() { //remove all tiles and then add updated ones
				//System.out.println((Main.person.x*100-1 00) + " " + (Main.person.y*100-100));

				// scrollBar.getHorizontalScrollBar().setValue(Math.min((Main.arlofLevels.get(Main.currentLvl).map[0].length - Main.person.y)*100, Main.person.y*100-300));
        // scrollBar.getVerticalScrollBar().setValue(Math.min((Main.arlofLevels.get(Main.currentLvl).map.length - Main.person.y)*100, Main.person.x*100-200));

        // System.out.println(Math.min((Main.arlofLevels.get(Main.currentLvl).map.length - Main.person.y)*100, Main.person.x*100-300));
        // System.out.println(Math.min((Main.arlofLevels.get(Main.currentLvl).map[0].length - Main.person.y)*100, Main.person.y*100-200));
        
            this.removeAll();
            this.setLayout(new GridLayout(Main.arlofLevels.get(Main.currentLvl).map.length,Main.arlofLevels.get(Main.currentLvl).map[0].length));
						
            // this.setLayout(new GridLayout(5,5));

            this.Panels =  new tileGUI[Main.arlofLevels.get(Main.currentLvl).map.length][Main.arlofLevels.get(Main.currentLvl).map[0].length];
            for (int i = 0; i < Main.arlofLevels.get(Main.currentLvl).map.length; i++) {
                for (int j = 0; j < Main.arlofLevels.get(Main.currentLvl).map[0].length; j++) {
                    tileGUI Tile = new tileGUI(new Tile("   "), 0, 0);
                    Tile.setPreferredSize(new Dimension(100, 100));
                    Tile.setMaximumSize(new Dimension(100, 100));
                    try{
                        Tile = new tileGUI(Main.arlofLevels.get(Main.currentLvl).map[i][j], i, j);

                    }catch(IndexOutOfBoundsException e){
                        Tile = new tileGUI(new Tile("   "), i, j);
                    }
                    this.Panels[i][j]=Tile;
                    this.add(Tile);

                }
                this.setPreferredSize(new Dimension(Main.arlofLevels.get(Main.currentLvl).map[0].length*100,Main.arlofLevels.get(Main.currentLvl).map.length*100));
                this.setSize(new Dimension(Main.arlofLevels.get(Main.currentLvl).map[0].length*100,Main.arlofLevels.get(Main.currentLvl).map.length*100));

								System.out.println("MAP SIZE " + this.size() + " " + new Dimension(Main.arlofLevels.get(Main.currentLvl).map.length*100,Main.arlofLevels.get(Main.currentLvl).map[0].length*100));
								
                validate();
                repaint();
            }
        }
        
    }