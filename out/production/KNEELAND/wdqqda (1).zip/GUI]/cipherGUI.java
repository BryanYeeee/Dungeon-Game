import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
    
    public class cipherGUI extends JPanel{
      public static JLabel Instructions;
      public static JPanel Inputs;
      public static int curItem;
      public Cipher curCipher;
      public boolean submitted = false;
			public JTextField answer;

        cipherGUI(Cipher curCipher) { //CANT REMOVE TEXTFIELD FROMBUTTON
					super(new BorderLayout());
					  this.curCipher = curCipher;
            this.submitted = false;
            JLabel name = new JLabel("Cipher");
            System.out.println(curCipher.instruction);
						Instructions = new JLabel(curCipher.instruction);
						Inputs = new JPanel();

            this.add(name, BorderLayout.NORTH);
            this.add(Instructions, BorderLayout.CENTER);

						answer = new JTextField();
						JButton submit = new JButton("BIG");

            answer.setPreferredSize(new Dimension(200,20));
            submit.setPreferredSize(new Dimension(40,20));
            submit.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                      System.out.println(answer.getText());
											if(!Main.gui.ciphScene.submitted){
											try {
											if(curCipher.hack(Integer.parseInt(answer.getText()))){
                        Main.gui.ciphScene.submitted = false;
												Main.gui.ciphScene.Instructions.setText("CORRECT, you know make money");
                      }else{
                        Main.gui.ciphScene.submitted = true;
												Main.gui.ciphScene.Instructions.setText("WRONG, you know loose health lol");
												Main.gui.ciphScene.Inputs.remove(Main.gui.ciphScene.answer);
            Main.gui.ciphScene.validate();
                      }
											} catch (Exception ex) {
												System.out.println(ex);
											}
											} else {
                      endCipher();
											}
                    }
            });
						Inputs.add(answer);
						Inputs.add(submit);
						Inputs.setLayout(new FlowLayout());
						this.add(Inputs, BorderLayout.SOUTH);




            this.setBackground(Color.MAGENTA);
            this.setPreferredSize(new Dimension(500,500));
            validate();
        }


        public static void endCipher() {
            GUI.updateBar();
            GUI.toggleMove(true);
            GUI.mainPanel.remove(GUI.ciphScene);
            GUI.mainPanel.add(GUI.scrollBar, BorderLayout.CENTER);
            GUI.map.updateMap();
            GUI.frame.validate();
            GUI.frame.repaint();
            System.out.println("You've HACKED GOD");
        }
        public static void startCipher(cipherGUI ciphScene){

                    GUI.mainPanel.removeAll();
                    GUI.toggleMove(false);
                    GUI.mainPanel.add(ciphScene);
                    GUI.ciphScene.validate();
                    GUI.ciphScene.repaint();
                    GUI.mainPanel.validate();
                    GUI.mainPanel.repaint();
                    GUI.frame.validate();
                    GUI.frame.repaint();
          
        }
                   
    }
  
