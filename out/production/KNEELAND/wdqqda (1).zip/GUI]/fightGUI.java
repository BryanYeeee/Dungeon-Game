import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
    
    public class fightGUI extends JPanel{
				public Enemy victim;
				public Fight battle;
				public static JPanel playerStats;
				public static JPanel enemyStats;
        public static JPanel fightButtons;

        fightGUI(Enemy victim, Fight battle) {
					super(new BorderLayout());
					  this.victim = victim;
					  this.battle = battle;
            JLabel name = new JLabel("FIGHT: you VS" + victim.name);
            this.add(name, BorderLayout.NORTH);
            JButton sword = new JButton("sword");
            JButton spell = new JButton("magic");
            JButton hammer = new JButton("hammer");
            JButton ability = new JButton("ability");
            JButton abilitydie = new JButton("ability");
            JButton ftstrike = new JButton("ftstrike");
            JButton heal = new JButton("heal");
            JButton stun = new JButton("stun");


            this.setBackground(Color.GREEN);
						fightButtons = new JPanel();
						fightButtons.setLayout(new GridLayout(1,4));
						this.add(fightButtons, BorderLayout.SOUTH);
            
						playerStats = new JPanel();
						enemyStats = new JPanel();
						playerStats.add(new JLabel("HEALTH: " + Main.person.health));
						enemyStats.add(new JLabel("HEALTH: " + battle.eHealth));
            
						this.add(playerStats, BorderLayout.EAST);
						this.add(enemyStats, BorderLayout.WEST);
            sword.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
									battle.attack(Main.person.inv.sword);
                  
								  updateFight();
                }
            });
            spell.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
									battle.attack(Main.person.inv.spell);
                  
								  updateFight();
                }
            });
            hammer.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
									battle.attack(Main.person.inv.hammer);
                  
									updateFight();
                }
            });
            ftstrike.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
									battle.ability("FTStrike");
                  
								  updateFight();
                }
            });
            heal.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
									battle.ability("Heal");
                  
								  updateFight();
                }
            });
            stun.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
									battle.ability("Stun");
                  
								  updateFight();
                }
            });
            ability.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                  fightButtons.removeAll();
                  fightButtons.add(ftstrike);
                  fightButtons.add(heal);
                  fightButtons.add(stun);
                  fightButtons.add(abilitydie);
                  fightButtons.validate();
                  fightButtons.repaint();
                }
            });
            abilitydie.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                  fightButtons.removeAll();
                  fightButtons.add(sword);
                  fightButtons.add(spell);
                  fightButtons.add(hammer);
                  fightButtons.add(ability);
                  fightButtons.validate();
                  fightButtons.repaint();
                }
            });

            
            fightButtons.add(sword);
						fightButtons.add(spell);
						fightButtons.add(hammer);
            fightButtons.add(ability);

            this.setPreferredSize(new Dimension(500,500));
            validate();
        }

        public void updateFight() {
          if(GUI.fightScene!=null){
        
            playerStats.removeAll();
            enemyStats.removeAll();
              playerStats.add(new JLabel("HEALTH: " + Main.person.health));
              enemyStats.add(new JLabel("HEALTH: " +  battle.eHealth));
            GUI.frame.validate();
            GUI.frame.repaint();
          }
          
				}
       

        public static void endFight() {
            GUI.updateBar();
            GUI.toggleMove(true);
            GUI.mainPanel.remove(GUI.fightScene);
            GUI.mainPanel.add(GUI.scrollBar, BorderLayout.CENTER);
            GUI.map.updateMap();
            System.out.println("You've defeated the victim");
        }
        public static void startFight(fightGUI fightScene, Enemy victim, Fight battle){
                    
                    GUI.mainPanel.removeAll();
                    // GUI.updateBar();
                    GUI.toggleMove(false);
                    GUI.mainPanel.add(fightScene);
                    GUI.fightScene.validate();
                    GUI.fightScene.repaint();
                    GUI.mainPanel.validate();
                    GUI.mainPanel.repaint();
                    GUI.frame.validate();
                    GUI.frame.repaint();
          
        }
                   
    }