import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class tileGUI extends JPanel{
        Tile currentTile;
        int x;
        int y;
        tileGUI(Tile tile, int x, int y) {
            super(new GridBagLayout());
            this.currentTile = tile;
						this.setBackground(new Color(235, 196, 0));
						if(!(tile.object instanceof Cipher) && !(tile.object instanceof Enemy) && !(tile.object instanceof Door) && !(tile.object instanceof Key) && !(tile.object == null)) {//<TEmp fix for no symbol objects
						this.add(new JLabel(new ImageIcon(tile.dir)));
						} else {
						this.add(new JLabel(tile.symbol));
						}

            this.x = x;
            this.y = y;
            this.setPreferredSize(new Dimension(100,100));

            validate();
        }

    }