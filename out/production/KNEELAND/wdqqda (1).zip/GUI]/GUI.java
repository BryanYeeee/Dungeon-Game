import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;

//BEGINNING GLITCHED, CAMERA DOESNT MOVE TO PLAYER WHEN MOVE LEVL
public class GUI {

    public static mapGUI map;
    public Dimension mapSize = new Dimension(500, 500);
    public static JScrollPane scrollBar = new JScrollPane();
    public static JFrame frame;
		public static fightGUI fightScene;
    public static shopGUI shopScene;
    public static cipherGUI ciphScene;
    public static JTextArea box;
		public static JPanel mainPanel = new JPanel();
    public static statGUI stats = new statGUI();

    public GUI() {
        map = new mapGUI();

        frame = new JFrame("TRAPINELANBASMET");
        frame.setResizable(false);
        frame.setLayout(new BorderLayout());	
        frame.setSize(new Dimension(800, 600));
        // showDialogue("NEELAN.TXT");
				frame.setBackground(Color.GREEN);
				mainPanel.setBackground(Color.BLUE);
        frame.add(mainPanel,BorderLayout.WEST);
        //mainPanel.add(stats, BorderLayout.SOUTH);
        updateBar();
        Main.gui.scrollToPlayer();
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("R"), "reset");
        frame.getRootPane().getActionMap().put("reset", reset);
        
        frame.setVisible(true);
        toggleMove(true);

    }

    public static void toggleMove(boolean on){
      if(on){
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("A"), "leftAction");
        frame.getRootPane().getActionMap().put("leftAction", left);
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("D"), "rightAction");
        frame.getRootPane().getActionMap().put("rightAction", right);
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("S"), "downAction");
        frame.getRootPane().getActionMap().put("downAction", down);
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("W"), "upAction");
        frame.getRootPane().getActionMap().put("upAction", up);

      }else if(!on){//make it easier to read
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("A"));
        frame.getRootPane().getActionMap().remove("leftAction");
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("D"));
        frame.getRootPane().getActionMap().remove("rightAction");
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("S"));
        frame.getRootPane().getActionMap().remove("downAction");
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("W"));
        frame.getRootPane().getActionMap().remove("upAction");

      }

    }

    public static void updateBar(){
        GUI.scrollBar = new JScrollPane(Main.gui.map, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        mainPanel.add(scrollBar,BorderLayout.NORTH);

				System.out.println("THE SIZE:" + Math.min(Main.arlofLevels.get(Main.currentLvl).map.length*100,700));
				System.out.println("THE AUTRE SIZE:" + Math.min(Main.arlofLevels.get(Main.currentLvl).map[0].length*100,500));
        scrollBar.setPreferredSize(new Dimension(Math.min(Main.arlofLevels.get(Main.currentLvl).map.length*100,700),Math.min(Main.arlofLevels.get(Main.currentLvl).map[0].length*100,500)));
        scrollBar.setSize(new Dimension(Math.min(Main.arlofLevels.get(Main.currentLvl).map.length*100,700),Math.min(Main.arlofLevels.get(Main.currentLvl).map[0].length*100,500)));



    }

		public static void scrollToPlayer() {
			if(Main.arlofLevels.get(Main.currentLvl).map[0].length*100 > Main.person.y*100-300) {
					if(Main.person.y*100-300 < 0) {
				scrollBar.getHorizontalScrollBar().setValue(1);
				System.out.println("A");
					} else {
				scrollBar.getHorizontalScrollBar().setValue(Main.person.y*100-300);
				System.out.println("B");
				  }
				} else {
				scrollBar.getHorizontalScrollBar().setValue(scrollBar.getHorizontalScrollBar().getMaximum());
				System.out.println("C");
				}
				if(Main.arlofLevels.get(Main.currentLvl).map.length*100 > Main.person.x*100-200) {
					if(Main.person.x*100-200 < 0) {
        		scrollBar.getVerticalScrollBar().setValue(1);
				System.out.println("D");
					} else {
        		scrollBar.getVerticalScrollBar().setValue(Main.person.x*100-200);
				System.out.println("E");
					}
				} else {
				scrollBar.getVerticalScrollBar().setValue(scrollBar.getVerticalScrollBar().getMaximum());
				System.out.println("F");
				}
		}

    public static void showDialogue(String dialogue){ 
      System.out.println(dialogue);
      if(box!=null){
        frame.remove(box);
      }
      
      box = new JTextArea(dialogue);
      box.setEditable(false);
      box.setBounds(500,0,800,100); 
      box.setFont(new Font("Comic Sans", 50, 50));
      frame.add(box, BorderLayout.SOUTH);
      frame.validate();
      frame.repaint();
    }

    public static void afterMove(){
        GUI.map.updateMap();
        Main.gui.scrollToPlayer();
        
        if(!Main.person.isAlive) { //dead
            System.out.println("YOU DIED");
            Main.person.worth = 0;
            Main.currentLvl = 0;
            Main.person.setLocation(Main.arlofLevels.get(Main.currentLvl).startx, Main.arlofLevels.get(Main.currentLvl).starty);
						Main.gui.scrollToPlayer();
            Main.person.inv.clearKeys();
            Main.person.atLadder = false;
        } else if(Main.person.atLadder){ //next level
            Main.currentLvl++;
            Main.person.setLocation(Main.arlofLevels.get(Main.currentLvl).startx, Main.arlofLevels.get(Main.currentLvl).starty);

            Main.person.inv.clearKeys();
            GUI.map.updateMap();
            
						Main.gui.scrollToPlayer();
            GUI.updateBar();
            GUI.mainPanel.removeAll();
            GUI.mainPanel.add(GUI.scrollBar, BorderLayout.CENTER);
            GUI.mainPanel.validate();
            GUI.mainPanel.repaint();

            Main.person.atLadder = false;

				
        }
        System.out.println("{" + Main.arlofLevels.get(Main.currentLvl).text + "}");
        System.out.println("Level: " + Main.arlofLevels.get(Main.currentLvl).levelnum);
        System.out.println("[Health: " + Main.person.health + "|Strength: " + Main.person.strength + "|Money: " + Main.person.worth + "]");
        System.out.println("--"+Main.person.inv.items+"--");
        Main.arlofLevels.get(Main.currentLvl).outputMap();
        GUI.frame.validate();
        GUI.frame.repaint();

    }
    public static void resetLevel(){
  
      Main.startGame();
    }



    static Action left = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
          if(Main.person.move("a", Main.arlofLevels.get(Main.currentLvl), true)){
            afterMove();
          }
      }
    };
    static Action right = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
          if(Main.person.move("d", Main.arlofLevels.get(Main.currentLvl), true)){
						afterMove();
          }
      }
    };
    static Action down = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
          if(Main.person.move("s", Main.arlofLevels.get(Main.currentLvl), true)){
            afterMove();
          }
      }
    };
    static Action up = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        if(Main.person.move("w", Main.arlofLevels.get(Main.currentLvl), true)){
          afterMove();
        }
      }
    };
    static Action reset = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
          resetLevel();
      }
    };
}
