import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class statGUI extends JPanel{

        statGUI() {
            this.setPreferredSize(new Dimension(800,100));
            updateStats();
            validate();
        }
        public void updateStats(){
          this.add(new JLabel(("<html> { " + Main.arlofLevels.get(Main.currentLvl).text + " } <br> Level: " + Main.arlofLevels.get(Main.currentLvl).levelnum + " <br> [Health: " + Main.person.health + "|Strength: " + Main.person.strength + "|Money: " + Main.person.worth + "] <br> --" + Main.person.inv.items + "--</html>")));
        }

    }