import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Tile {
    Object object;
    String symbol;
		String dir;
    Random rand = new Random();

    public Tile(String object) {
        this.symbol = object;
        switch (object) {
            case " - ":
                this.object = null;
                break;
            case " H ":
            case "   ": // < WHY DOES THIS EXIST???
                this.object = new Wall();
								this.dir = (new Wall()).dir;
                break;
            case " # ":
                this.object = new Ladder();
								this.dir = (new Ladder()).dir;
                break;
            case " $ ":
                this.object = new Coin();
								this.dir = (new Coin()).dir;
                break;
            case " @ ":
                this.object = new Health();
								this.dir = (new Health()).dir;
                break;
            case " * ":
                this.object = new Ability();
								this.dir = (new Wall()).dir;
                break;
            case " ! ":
                this.object = new Steroid();
								this.dir = (new Steroid()).dir;
                break;
            case " S1":
                this.symbol = " S ";
                this.object = new Shop(Arrays.asList("Strength,3,5", "Health,100,5")); //item, amount, cost
								this.dir = ((Shop)this.object).dir;
								break;
            default:
                this.object = null;
                break;

        }
    }
    public Tile(int line){
      this.symbol = " X ";
      this.object = new Neelan(line);
			this.dir = ((Neelan)this.object).dir;
    }
    public Tile(Player person) {
        this.symbol = " O ";
        this.object = person;
			this.dir = "PlayerIcon.png";
    }
    public Tile(int x, int y) { //create Teleporter
        this.symbol = " U ";
        this.object = new Teleporter(x,y);
			this.dir = ((Teleporter)this.object).dir;
    }

    public Tile(String object, int x, int y){//create enemy
        this.symbol = object.substring(0,3);
        switch (object.substring(0,3)) {
            case " E ": //skeleton
                this.object = new Enemy(10,75,x,y,rand.nextInt(2) + 3, "hammer", "spell", "skeleton");
                break;
            case " 8 ": //ogre
                this.object = new Enemy(15,150,x,y,rand.nextInt(5) + 15, "sword", "hammer", "ogre");
                break;
            case " C ": //cyborg
                this.object = new Enemy(25,35,x,y,rand.nextInt(5) + 5, "spell", "sword", "disabled guy");
                break;
        }
        if(object.length() > 3) {
            ((Enemy)this.object).addKey(Integer.parseInt(object.substring(3,4)));
        }
    }

    public Tile(String object, int id) { //create door key
        switch (object) {
            case "door":
                this.symbol = "|"+id+"|";
                this.object = new Door(id);
                break;
            case "key":
                this.symbol = "<"+id+">";
                this.object = new Key(id);
                break;
            case "cipher":
                this.symbol = " & ";
								this.object = new PatternCipher(id,0,"");
                //  switch(String.valueOf(rand.nextInt(2))) {
                //  	case "0":
                //  			this.object = new AsciiCipher(id,0,"");
                //  			break;
                //  	case "1":
                //  			this.object = new PatternCipher(id,0,"");
                //  			break;
                //  }
                break;

        }
    }
}
