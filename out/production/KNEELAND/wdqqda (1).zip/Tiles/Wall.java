public class Wall {
  String dir = "WallIcon.png";

    public Wall() {
      
    }
}
