public class Teleporter {
  int x;
  int y;
  String dir = "TeleporterIcon.png";
    public Teleporter(int x, int y) {
      this.x = x;
      this.y = y;
    }
}