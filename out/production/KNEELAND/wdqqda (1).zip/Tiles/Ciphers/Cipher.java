public abstract class Cipher {
		int dif;
    int key;
    String instruction;

    public Cipher(int dif, int key, String instruction) { 
			this.dif = dif;
      this.key = key;
      this.instruction = instruction;
    }

    public abstract boolean hack(int answer);
}
