public class Door {
    int id;
    public Door(int id) {
        this.id = id;
    }
}
