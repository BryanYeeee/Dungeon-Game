public class Ladder {

String dir = "LadderIcon.png";
    public Ladder() { 
    }
}
