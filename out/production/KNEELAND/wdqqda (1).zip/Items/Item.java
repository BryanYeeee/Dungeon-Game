public abstract class Item {
    public Item() {
    }
    public abstract void pickUp(Player person);

}