public class Steroid extends Item {
  String dir = "SteroidIcon.png";
    public Steroid() {
    }
    public void pickUp(Player person) {
        System.out.println("STEROID WAS PICKED UP");
        person.strength = (int) (person.strength*2);
        return;
    }
}
