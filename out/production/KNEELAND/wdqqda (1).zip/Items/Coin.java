public class Coin extends Item {
    String dir = "CoinIcon.png";
    public Coin() {
    }
    public void pickUp(Player person) {
        System.out.println("COIN WAS PICKED UP");
        person.worth++;
        return;
    }
}