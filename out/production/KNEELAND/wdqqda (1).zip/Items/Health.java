public class Health extends Item {
    String dir = "HealthIcon.png";
    public Health() {
    }
    public void pickUp(Player person) {
        System.out.println("HEALTH WAS PICKED UP");
        person.health = person.health + 10;
        return;
    }

}
