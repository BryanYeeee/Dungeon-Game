public class Hammer extends Weapon {
  public Hammer(double damage, String name){
    super(damage, name);
  }
  public void pickUp(Player person) {
    person.inv.hammer = this;
    return;
  }
}