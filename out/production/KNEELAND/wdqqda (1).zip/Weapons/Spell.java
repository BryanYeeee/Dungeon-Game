public class Spell extends Weapon {
  public Spell(double damage, String name){
    super(damage, name);
  }
  public void pickUp(Player person) {
    person.inv.spell = this;
    return;
  }
}