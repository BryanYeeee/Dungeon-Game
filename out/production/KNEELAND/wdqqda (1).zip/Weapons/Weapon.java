public abstract class Weapon extends Item {
  double damage;
  String name;

    public Weapon(double damage, String name) {
        this.damage = damage;
        this.name = name;
    }
    abstract public void pickUp(Player person);
}
