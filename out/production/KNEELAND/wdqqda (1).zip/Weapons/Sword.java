public class Sword extends Weapon {
  public Sword(double damage, String name){
    super(damage, name);
  }
  public void pickUp(Player person) {
    person.inv.sword = this;
    return;
  }
}