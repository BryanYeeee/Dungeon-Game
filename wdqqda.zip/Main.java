import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.*;

public class Main {

    public static void main(String args[]) {
        ArrayList<Level> arlofLevels = new ArrayList<Level>();
        int currentLvl = 7;//+2
        Scanner sc = new Scanner(System.in);
        Player person = new Player(4,150,0);
        System.out.println("+------ WELCOME TO YOUR DOOM ------+");
        System.out.println("|        -- Pick a Stick --        |");
        System.out.println("| -+ (1)Sword (2)Wand (3)Hammer +- |");
        System.out.println("|        -- Pick a Stick --        |");
        System.out.println("+---- -+--------------------+- ----+");
        boolean yesWeapon = false;
        while (!yesWeapon){
                switch(sc.nextLine()) {
                  case "1":
                  person.inv.upgradeWeapon("Sword", 2);
                  yesWeapon = true;
                  break;
                  case "2":
                  person.inv.upgradeWeapon("Wand", 2);
                   yesWeapon = true;
                  break;
                  case "3":
                  person.inv.upgradeWeapon("Hammer", 2);
                  yesWeapon = true;
                  break;
                  
                }
        }
        String[][] lvlMove = {  {" O ", " H ", " # "},
                                {" - ", " H ", " - "},
                                {" - ", " H ", " - "},
                                {" - ", " H ", " - "},
                                {" - ", " - ", " - "} };
        arlofLevels.add(new Level(lvlMove, 1, person, 0, 0, "WASD for Movement"));


        String[][] lvlItems = { {" $ ", " $ ", " $ ", " - "},
                                {" - ", " $ ", " $ ", " - "},
                                {" O ", " H ", " H ", " # "},
                                {" - ", " @ ", " @ ", " - "},
                                {" @ ", " @ ", " @ ", " - "} };
        arlofLevels.add(new Level(lvlItems, 2, person, 2, 0, "Pickup Items, $ for Coins, @ for Health"));

        String[][] lvlSword = { {" H ", " H ", " # ", " H ", " H "},
                                {" H ", " H ", " - ", " H ", " H "},
                                {" H ", " - ", " ! ", " - ", " H "},
                                {" H ", " - ", " - ", " - ", " H "},
                                {" H ", " - ", " O ", " - ", " H "} };
        arlofLevels.add(new Level(lvlSword, 3, person, 4, 2, "Don't Go Wandering Alone, Take this Steroid with you, or I will find you... (!)"));

        String[][] lvlSkeleton = { {" O ", " - ", " - ", " - ", " - "},
                                   {" - ", " - ", " - ", " H ", " - "},
                                   {" H ", " H ", " H ", " H ", " E "},
                                   {" @ ", " @ ", " - ", " - ", " - "},
                                   {" # ", " @ ", " - ", " - ", " - "}};
        arlofLevels.add(new Level(lvlSkeleton, 4, person, 0, 0, "Fight The Skeleton! (E)"));

        String[][] lvlShop = { {" - ", " - ", " - ", " - ", " - " },
                               {" - ", " S1", " - ", " # ", " - " },
                               {" - ", " - ", " - ", " - ", " - " },
                               {" - ", " O ", " - ", " - ", " - " },
                               {" - ", " - ", " - ", " - ", " - " }};
        arlofLevels.add(new Level(lvlShop, 5, person, 3, 1, "Spend your money on items in the SHOP"));

        String[][] lvlKeyDoor = { 
                {" @ ", "<2>", " @ ", " H ", " - ", " $ "},
                {" - ", " - ", " - ", "|2|", " - ", " # "},
                {" - ", " - ", " - ", " H ", " - ", " $ "},
                {" H ", "|1|", " H ", " H ", " H ", " H "},
                {" - ", " - ", " O ", " H ", " $ ", " $ "},
                {"<1>", " - ", " - ", "|2|", " $ ", " $ "}};
        arlofLevels.add(new Level(lvlKeyDoor, 6, person, 4, 2, "Use the keys to open the matching door, also there are metal men now"));

         String[][] lvlApx1 = {
                {" # ", " $ ", "|2|", " $ ", " C ", " H ", "<3>"   },
                {" E ", " $ ", " H ", " $ ", " E 4", " H ", "|2|" },
                {" H ", " H ", " H ", "|3|", " H ", " H ", " O "  },
                {" C ", " - ", " - ", " - ", " - ", "|1|", " - "  },
                {" H ", "|1|", " H ", " H ", " H ", " H ", " - "  },
                {" @ ", " @ ", " H ", " @ ", " C ", " H ", " - "  },
                {" C 2", " @ ", "|4|", " @ ", " @ ", " H ", " E 1"}, //need to introduce C
        };
        arlofLevels.add(new Level(lvlApx1, 7, person, 2, 6, "Enemies Can Drop Keys"));

        String[][] lvlApx2 = {
                {" O ", " - ", "|1|", " - ", " - ", " 8 ", " $ "},
                {" H ", " - ", " H ", " H ", " - ", " H ", " @ "},
                {" - ", " - ", " H ", " - ", " - ", " H ", " - "},
                {" - ", " H ", " H ", " - ", " H ", " H ", " $ "},
                {" - ", " - ", " H ", " - ", " - ", " H ", " @ "},
                {" E 1", " C ", " H ", " - ", " E ", " H ", " - "},
                {" - ", " - ", " H ", " - ", " - ", " H ", " $ "},
                {" - ", " - ", " H ", " C 2", " E ", " H ", " @ "},
                {" - ", " E 3", " H ", " - ", " - ", " H ", " - "},
                {"|1|", " H ", " H ", "|2|", " H ", " H ", " $ "},
                {" @ ", " @ ", " H ", " @ ", " @ ", " H ", " @ "},
                {" @ ", " @ ", " H ", " @ ", " @ ", " H ", " - "},
                {" H ", " H ", " H ", " H ", " H ", " H ", " - "},
                {" # ", " @ ", " @ ", " @ ", "|3|", "|2|", "|1|"},
        };
        arlofLevels.add(new Level(lvlApx2, 8, person, 0, 0, "Ogre (8), are Stronger, Find Their Weakness to Beat Them"));
        
      String[][] lvlApx3 = {
          {" 8 2",  "11U8" ,  " H ",  " @ ",  " @ ",  " @ ",  " H ", " 8 1", " C "},
          {"|1|",  " H ",  " H ",  " @ ",  "7U5",  " @ ",  " - ",  " - ",  " - "},
          {" @ ",  "11U0", " H ",  " @ ",  " @ ",  " @ ",  " H ",  " - ",  " - "},
          {" @ ",  " @ ",  " H ",  " H ",  " H ",  " H ",  " H ",  " H ",  " H "},
          {" C ",  " H ",  " H ",  "7U5",  " @ ",  " - ",  " H ",  " @ ",  " @ "},
          {" @ ",  " @ ",  " H ",  " H ",  " H ",  " H ",  " H ",  " @ ",  " * "}, // < ABILITY THERE
          {" H ",  " - ",  " H ",  " H ",  " H ",  "2U8",  " H ",  " @ ",  " @ "},
          {" - ",  " - ",  " H ",  " - ",  "12U5", " - ",  " H ",  " H ",  "|4|"},
          {" H ",  " H ",  " H ",  " @ ",  "4U5",  " H ",  " H ",  "7U0",  " - "},
          {" @ ",  " @ ",  " H ",  " H ",  " H ",  " H ",  " H ",  " - ",  " - "},
          {" - ",  " - ",  " E ",  "12U5", " H ", "11U3", " H ",  " - ",  " - "},
          {" - ",  " - ",  " C ",  " - ",  " H ",  " C ",  " H ",  " - ",  " - "},
          {" H ",  " - ",  " H ",  "7U3",  " H ",  " - ",  " H ",  " H ",  "|3|"},
          {" O ",  "7U0",  " H ",  " H ",  " H ",  "|2|",  " H ",  " $ ",  " $ "},
          {" H ",  " - ",  " 8 4", " @ ", " H ",   " E 3",  " H ", "14U1",  " # "},
          };/////////////////^Teleport here
        arlofLevels.add(new Level(lvlApx3, 9, person, 13, 0, "BIG BOI MAZE with TELEPORTERS (U)"));

        String[][] lvlShop2 = { {" - ", " - ", " - ", " - ", " - " },
                               {" - ", " S1", " - ", " # ", " - " },
                               {" - ", " - ", " - ", " - ", " - " },
                               {" - ", " O ", " - ", " - ", " - " },
                               {" - ", " - ", " - ", " - ", " - " }};
        arlofLevels.add(new Level(lvlShop2, 10, person, 3, 1, "Spend your money on items in the SHOP"));
        while(true) {
            if(!person.isAlive) { //dead
                System.out.println("YOU DIED");
                person.worth = 0;
                currentLvl = 0;
                person.setLocation(arlofLevels.get(currentLvl).startx, arlofLevels.get(currentLvl).starty);
                person.inv.clearKeys();
                person.atLadder = false;
                break;
            } else if(person.atLadder){ //next level
                currentLvl++;
                person.setLocation(arlofLevels.get(currentLvl).startx, arlofLevels.get(currentLvl).starty);
                person.inv.clearKeys();
                person.atLadder = false;
            }
//            System.out.println("-- " + arlofLevels.get(currentLvl).arlofKeys + " --");
            System.out.println("{" + arlofLevels.get(currentLvl).text + "}");
            System.out.println("Level: " + arlofLevels.get(currentLvl).levelnum);
            System.out.println("[Health: " + person.health + "|Strength: " + person.strength + "|Money: " + person.worth + "]");
            System.out.println("--"+person.inv.items+"--");

            arlofLevels.get(currentLvl).outputMap();
            String move = sc.nextLine();
            person.move(move, arlofLevels.get(currentLvl), true);
            System.out.println();
        }

    }
}
