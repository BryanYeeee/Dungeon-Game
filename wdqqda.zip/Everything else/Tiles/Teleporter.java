public class Teleporter {
  int x;
  int y;
    public Teleporter(int x, int y) {
      this.x = x;
      this.y = y;
    }
}