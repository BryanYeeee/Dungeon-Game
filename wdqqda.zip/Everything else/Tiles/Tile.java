import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Tile {
    Object object;
    String symbol;
    Random rand = new Random();

    public Tile(String object) {
        this.symbol = object;
        switch (object) {
            case " - ":
                this.object = null;
                break;
            case " H ":
                this.object = new Wall();
                break;
            case " # ":
                this.object = new Ladder();
                break;
            case " $ ":
                this.object = new Coin();
                break;
            case " @ ":
                this.object = new Health();
                break;
            case " * ":

                this.object = new Ability();
                break;
            case " ! ":
                this.object = new Steroid();
                break;
            case " S1":
                this.symbol = " S ";
                this.object = new Shop(Arrays.asList("Strength,3,5", "Health,100,5")); //item, amount, cost
                break;
            default:
                this.object = null;
                break;

        }
    }

    public Tile(Player person) {
        this.symbol = " O ";
        this.object = person;
    }
    public Tile(int x, int y) { //create Teleporter
      this.symbol = " U ";
      this.object = new Teleporter(x,y);
    }

    public Tile(String object, int x, int y){//create enemy
        this.symbol = object.substring(0,3);
        switch (object.substring(0,3)) {
            case " E ": //skeleton
                this.object = new Enemy(10,75,x,y,rand.nextInt(2) + 3, "hammer", "spell");
                break;
            case " 8 ": //ogre
                this.object = new Enemy(15,150,x,y,rand.nextInt(5) + 15, "sword", "hammer");
                break;
            case " C ": //cyborg
                this.object = new Enemy(25,35,x,y,rand.nextInt(5) + 5, "spell", "sword");
                break;
        }
        if(object.length() > 3) {
            ((Enemy)this.object).addKey(Integer.parseInt(object.substring(3,4)));
        }
    }

    public Tile(String object, int id) { //create door key
        switch (object) {
            case "door":
                this.symbol = "|"+id+"|";
                this.object = new Door(id);
                break;
            case "key":
                this.symbol = "<"+id+">";
                this.object = new Key(id);
                break;
        }
    }
}
