public class Coin extends Item {
    public Coin() {
    }
    public void pickUp(Player person) {
        System.out.println("COIN WAS PICKED UP");
        person.worth++;
        return;
    }
}