public abstract class Weapon extends Item {
  double damage;
  
    public Weapon(double damage) {
        this.damage = damage;
    }
    abstract public void pickUp(Player person);
}
