public class Hammer extends Weapon {
  public Hammer(double damage){
    super(damage);
  }
  public void pickUp(Player person) {
    person.inv.hammer = this;
    return;
  }
}