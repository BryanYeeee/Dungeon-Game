public class Sword extends Weapon {
  public Sword(double damage){
    super(damage);
  }
  public void pickUp(Player person) {
    person.inv.sword = this;
    return;
  }
}