public class Spell extends Weapon {
  public Spell(double damage){
    super(damage);
  }
  public void pickUp(Player person) {
    person.inv.spell = this;
    return;
  }
}