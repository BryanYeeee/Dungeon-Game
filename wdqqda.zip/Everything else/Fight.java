import java.util.Random;
import java.util.Scanner;

public class Fight{
  public static void battle(Player person, int eHealth, int eStrength, int eWorth, String eWeak, String eResist, int eKey) {// e=enemy

  
          Random rand = new Random();
          Scanner sc = new Scanner(System.in);;
          boolean enemyturn = true;
          
          int stunned = 0;
          person.inv.curatks = person.inv.atks;


          while(person.health>0&&eHealth>0){
            



              System.out.println("== phealth:" + person.health + " pStrength:" + person.strength + " eHealth:" + eHealth + " eStrength:" + eStrength + " ==");
              
              //Your Turn
              System.out.println("Your Turn:1[sword] 2[spell] 3[hammer] 4[Ability]");
              String move = sc.nextLine();
              double weaponBonus = 1;
              
              switch(move) {
                case "1":
                move = "sword";
                break;
                case "2":
                move = "spell";
                break;
                case "3":
                move = "hammer";
                break;
                case "4":
                move = "ability";
                break;
              }
              if(eWeak.equals(move)){
                weaponBonus = 1.5;
              } else if(eResist.equals(move)){
                weaponBonus = 0.75;
              }
              if(rand.nextInt(4) > 3) {
                weaponBonus = weaponBonus + 0.5;
              } 
              switch(move) {
                case "sword": 
            System.out.println((int)((person.inv.sword.damage*person.strength)*weaponBonus));
                  eHealth = eHealth - 
                  (int)((person.inv.sword.damage*person.strength)*weaponBonus);
                  break;
                case "spell":
            System.out.println((int)((person.inv.spell.damage*person.strength)*weaponBonus));
                  eHealth = eHealth - 
                  (int)((person.inv.spell.damage*person.strength)*weaponBonus);
                  break;
                case "hammer":
            System.out.println((int)((person.inv.hammer.damage*person.strength)*weaponBonus));
                  eHealth = eHealth - 
                  (int)((person.inv.hammer.damage*person.strength)*weaponBonus);
                  break;
                case "ability":
              
                String ability = sc.nextLine();
                switch(ability){
                  case "1":
                  if(person.inv.curatks.contains("FTStrike")){
                  person.inv.curatks.remove("FTStrike");  
                  eHealth = eHealth - Ability.FTStrike(person);
                  }
                  break;
                  case "2":
                  if(person.inv.curatks.contains("Heal")){
                  person.inv.curatks.remove("Heal");  
                  person.health = eHealth;
                  }

                  break;
                  case "3":
                  if(person.inv.curatks.contains("Heal")){
                  person.inv.curatks.remove("Heal");  
                  eHealth = eHealth - Ability.Stun(person);
                    if(rand.nextInt(3) == 1){
                      System.out.println("ENEMY is now crippled! :D");
                        enemyturn=false;
                        stunned=2;
                    }
                  }
                  break;
                }
                break;
              }
              if(eHealth <= 0) {
                  person.worth = person.worth + eWorth;
                  if(eKey > 0) {
                      person.inv.add("<"+eKey+">");
                  }
                  return;
              }
              //EMemy Eturn
              stunned--;
              if(stunned<=0){
              enemyturn = true;

              }
              if(enemyturn){
              person.health=person.health-(rand.nextInt(10) + eStrength);
            }

          }
              if(person.health <= 0) {
                  person.health = 0;
                  person.isAlive = false;
                  return;
              }

      }
 }