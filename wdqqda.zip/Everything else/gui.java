import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

 public class gui {

   public mapGUI warfieldpiece;
	 public Dimension mapSize = new Dimension(500, 500);

	public gui() {
        this.warfieldpiece = new mapgraphics();
        this.warfieldpiece.setSize(200);
        this.warfieldpiece.setPreferredSize(200);
        
        this.panel = new JPanel();
        this.panel.setLayout(new BorderLayout());
        this.panel.setSize(toomuch);
        this.panel.add(this.warfieldpiece, BorderLayout.WEST);

				JFrame frame = new JFrame("THINGS HERE");
        frame.setLayout(new BorderLayout());
				frame.setSize(100, 100);
				frame.add(new JLabel("asd"));
				frame.setVisible(true);	
        frame.add(this.panel,BorderLayout.CENTER);
	}

  public class mapGui extends JPanel {
            gui.tilegraphics[][] warfieldpiece;
            mapGui() {
              //8 8 = length width of mapgraphics
                super(new GridLayout(8, 8));
                this.warfieldpiece =  new gui.tilegraphics[8][8];
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        gui.tilegraphics pieceg = new gui.tilegraphics(this, i, j);
                        this.warfieldpiece[i][j]=pieceg;
                        add(pieceg);
                    }
                    setPreferredSize();
                    validate();
                    repaint();
                }
            }

            public void updateMap() {
                removeAll();
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                            gui.tilegraphics pieceg = new gui.tilegraphics(this, i, j);
                            this.warfieldpiece[i][j]=pieceg;
                            add(pieceg);
                    }
                    setPreferredSize(toolittle);
                    validate();
                }
            }

    }
     public class tileGUI extends JPanel {
           int x;
           int y;
           tileGUI(gui.mapgraphics warfieldpiece, int x, int y) {
               super(new GridBagLayout());
              this.x = x;
               this.y = y;
              validate();
           }
         }
}